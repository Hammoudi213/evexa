async function setupProductAutocomplete(input) {
    input.addEventListener('input', async () => {
        const response = await fetch(`/products/suggestions?q=${input.value}`);
        const products = await response.json();

        let datalist = document.getElementById('product-suggestions');
        if (!datalist) {
            datalist = document.createElement('datalist');
            datalist.id = 'product-suggestions';
            document.body.appendChild(datalist);
        }

        datalist.innerHTML = products.map(product => 
            `<option value="${product}">`
        ).join('');
    });
}

function addProductEntry() {
    const container = document.getElementById('products-container');
    const newEntry = document.createElement('div');
    newEntry.className = 'product-entry mb-3';
    newEntry.innerHTML = `
        <div class="row">
            <div class="col-md-4">
                <label class="form-label">${translations.productLabel}</label>
                <input type="text" class="form-control" name="product[]" list="product-suggestions" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">${translations.quantityLabel}</label>
                <input type="number" class="form-control" name="quantity[]" required min="1">
            </div>
            <div class="col-md-3">
                <label class="form-label">${translations.batchLabel}</label>
                <input type="text" class="form-control" name="batch_number[]" required>
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <button type="button" class="btn btn-danger mb-2" onclick="removeProductEntry(this)">×</button>
            </div>
        </div>
    `;
    container.appendChild(newEntry);
    setupProductAutocomplete(newEntry.querySelector('input[name="product[]"]'));
}

document.addEventListener('DOMContentLoaded', () => {
    const existingInputs = document.querySelectorAll('input[name="product[]"]');
    existingInputs.forEach(setupProductAutocomplete);
});

function removeProductEntry(button) {
    const productEntries = document.getElementsByClassName('product-entry');
    if (productEntries.length > 1) {
        button.closest('.product-entry').remove();
    }
}

function uploadFile(deliveryId) {
    const form = document.getElementById(`proofForm_${deliveryId}`);
    const formData = new FormData(form);

    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            const formContainer = form.parentElement;
            const viewButton = document.createElement('a');
            viewButton.href = `/delivery/${deliveryId}/proof`;
            viewButton.className = 'btn btn-sm btn-info';
            viewButton.target = '_blank';
            viewButton.textContent = document.documentElement.lang === 'fr' ? 'Voir le document' : 'معاينة المستند';
            formContainer.innerHTML = '';
            formContainer.appendChild(viewButton);
        }
    });
}

function showDeliveryDetails(id) {
    const detailsRow = document.getElementById(`details-${id}`);
    if (detailsRow.style.display === 'none') {
        detailsRow.style.display = 'table-row';
    } else {
        detailsRow.style.display = 'none';
    }
}