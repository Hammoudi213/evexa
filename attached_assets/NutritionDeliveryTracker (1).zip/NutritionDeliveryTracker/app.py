import os
import io
import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, session, g, jsonify
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from weasyprint import HTML
import tempfile

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)

app.secret_key = os.environ.get("FLASK_SECRET_KEY") or "delivery-tracking-secret"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///delivery.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

@app.before_request
def before_request():
    g.lang = session.get('lang', 'ar')

@app.route('/set-language/<lang>')
def set_language(lang):
    if lang in ['ar', 'fr']:
        session['lang'] = lang
    next_page = request.args.get('next', '/')
    return redirect(next_page)

@app.route('/')
def index():
    return render_template('index.html', lang=g.lang)

@app.route('/new_delivery', methods=['GET', 'POST'])
def new_delivery():
    from models import Delivery, DeliveryItem

    if request.method == 'POST':
        try:
            delivery = Delivery(
                recipient_name=request.form['recipient_name'],
                recipient_job=request.form['recipient_job'],
                region=request.form['region'],
                delivery_date=datetime.strptime(request.form['delivery_date'], '%Y-%m-%d'),
                status='pending'  # Set default status
            )

            products = request.form.getlist('product[]')
            quantities = request.form.getlist('quantity[]')
            batch_numbers = request.form.getlist('batch_number[]')

            for p, q, b in zip(products, quantities, batch_numbers):
                if p.strip() and q.strip() and b.strip():  # Only add if all fields are filled
                    item = DeliveryItem(
                        product_name=p.strip(),
                        quantity=int(q),
                        batch_number=b.strip()
                    )
                    delivery.items.append(item)

            if not delivery.items:
                raise ValueError('At least one product is required')

            db.session.add(delivery)
            db.session.commit()
            flash('Livraison créée avec succès' if g.lang == 'fr' else 'تم إنشاء مستند التسليم بنجاح', 'success')
            return redirect(url_for('view_deliveries'))
        except ValueError as e:
            flash(str(e), 'danger')
            return redirect(url_for('new_delivery'))
        except Exception as e:
            db.session.rollback()
            flash('Erreur lors de la sauvegarde' if g.lang == 'fr' else 'حدث خطأ أثناء حفظ المستند', 'danger')
            return redirect(url_for('new_delivery'))

    return render_template('new_delivery.html', lang=g.lang)

@app.route('/deliveries')
def view_deliveries():
    from models import Delivery
    query = Delivery.query

    # Apply filters
    if recipient := request.args.get('recipient'):
        query = query.filter(Delivery.recipient_name.ilike(f'%{recipient}%'))

    if region := request.args.get('region'):
        query = query.filter(Delivery.region.ilike(f'%{region}%'))

    if date_from := request.args.get('date_from'):
        query = query.filter(Delivery.delivery_date >= datetime.strptime(date_from, '%Y-%m-%d'))

    if date_to := request.args.get('date_to'):
        query = query.filter(Delivery.delivery_date <= datetime.strptime(date_to, '%Y-%m-%d'))

    if status := request.args.get('status'):
        query = query.filter(Delivery.status == status)

    deliveries = query.order_by(Delivery.delivery_date.desc()).all()
    return render_template('view_deliveries.html', deliveries=deliveries, lang=g.lang)


@app.route('/delivery/<int:delivery_id>/pdf')
def delivery_pdf(delivery_id):
    from models import Delivery
    delivery = Delivery.query.get_or_404(delivery_id)
    lang = request.args.get('lang', g.lang)

    # Render the template to HTML
    html = render_template('delivery_pdf.html', delivery=delivery, lang=lang)

    # Create a temporary file
    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
        HTML(string=html).write_pdf(f.name)

        # Return the PDF file
        return send_file(
            f.name,
            download_name=f'delivery-{delivery_id}.pdf',
            mimetype='application/pdf'
        )

@app.route('/delivery/<int:delivery_id>/label')
def delivery_label(delivery_id):
    from models import Delivery
    delivery = Delivery.query.get_or_404(delivery_id)
    lang = request.args.get('lang', g.lang)

    # Render the template to HTML
    html = render_template('delivery_label.html', delivery=delivery, lang=lang)

    # Create a temporary file
    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
        HTML(string=html).write_pdf(f.name)

        # Return the PDF file
        return send_file(
            f.name,
            download_name=f'label-{delivery_id}.pdf',
            mimetype='application/pdf'
        )

@app.route('/delivery/<int:delivery_id>/status', methods=['POST'])
def update_status(delivery_id):
    from models import Delivery
    delivery = Delivery.query.get_or_404(delivery_id)
    status = request.form.get('status')
    if status in ['pending', 'delivered', 'cancelled']:
        delivery.status = status
        db.session.commit()
        flash('Statut mis à jour avec succès' if g.lang == 'fr' else 'تم تحديث الحالة بنجاح', 'success')
    return redirect(url_for('view_deliveries'))

@app.route('/delivery/<int:delivery_id>/delete', methods=['POST'])
def delete_delivery(delivery_id):
    from models import Delivery
    delivery = Delivery.query.get_or_404(delivery_id)
    db.session.delete(delivery)
    db.session.commit()
    flash('Livraison supprimée avec succès' if g.lang == 'fr' else 'تم حذف مستند التسليم بنجاح', 'success')
    return redirect(url_for('view_deliveries'))

@app.route('/import-products', methods=['POST'])
def import_products():
    from models import Product
    if 'file' not in request.files:
        flash('لم يتم اختيار ملف', 'danger')
        return redirect(url_for('index'))

    file = request.files['file']
    if file.filename == '':
        flash('لم يتم اختيار ملف', 'danger')
        return redirect(url_for('index'))

    if not file.filename.endswith('.xlsx'):
        flash('يجب أن يكون الملف بصيغة Excel (.xlsx)', 'danger')
        return redirect(url_for('index'))

    try:
        import pandas as pd
        df = pd.read_excel(file)
        product_column = df.columns[0]  # افتراض أن العمود الأول يحتوي على أسماء المنتجات

        for product_name in df[product_column]:
            if not Product.query.filter_by(name=str(product_name).strip()).first():
                db.session.add(Product(name=str(product_name).strip()))

        db.session.commit()
        flash('تم استيراد المنتجات بنجاح', 'success')
    except Exception as e:
        flash(f'حدث خطأ أثناء استيراد المنتجات: {str(e)}', 'danger')

    return redirect(url_for('index'))

@app.route('/products/suggestions')
def get_product_suggestions():
    search = request.args.get('q', '')
    from models import Product
    products = Product.query.filter(Product.name.ilike(f'%{search}%')).order_by(Product.name).all()
    return jsonify([product.name for product in products])

@app.route('/products')
def get_all_products():
    from models import Product
    products = Product.query.order_by(Product.name).all()
    return jsonify([product.name for product in products])

@app.route('/export_backup')
def export_backup():
    from models import Delivery, DeliveryItem, Product
    data = {
        'deliveries': [],
        'products': []
    }
    
    # تصدير التسليمات
    deliveries = Delivery.query.all()
    for delivery in deliveries:
        delivery_data = {
            'recipient_name': delivery.recipient_name,
            'recipient_job': delivery.recipient_job,
            'region': delivery.region,
            'delivery_date': delivery.delivery_date.isoformat(),
            'status': delivery.status,
            'items': []
        }
        
        for item in delivery.items:
            delivery_data['items'].append({
                'product_name': item.product_name,
                'quantity': item.quantity,
                'batch_number': item.batch_number
            })
        
        data['deliveries'].append(delivery_data)
    
    # تصدير المنتجات
    products = Product.query.all()
    for product in products:
        data['products'].append({
            'name': product.name
        })

    return send_file(
        io.BytesIO(json.dumps(data, ensure_ascii=False).encode('utf-8')),
        mimetype='application/json',
        as_attachment=True,
        download_name='backup.json'
    )

@app.route('/import_backup', methods=['POST'])
def import_backup():
    if 'backup_file' not in request.files:
        flash('لم يتم اختيار ملف', 'danger')
        return redirect(url_for('view_deliveries'))

    file = request.files['backup_file']
    if file.filename == '':
        flash('لم يتم اختيار ملف', 'danger')
        return redirect(url_for('view_deliveries'))

    try:
        data = json.load(file)
        from models import Delivery, DeliveryItem, Product
        
        # حذف البيانات الحالية
        DeliveryItem.query.delete()
        Delivery.query.delete()
        Product.query.delete()
        
        # استيراد المنتجات
        for product_data in data['products']:
            product = Product(name=product_data['name'])
            db.session.add(product)
        
        # استيراد التسليمات
        for delivery_data in data['deliveries']:
            delivery = Delivery(
                recipient_name=delivery_data['recipient_name'],
                recipient_job=delivery_data['recipient_job'],
                region=delivery_data['region'],
                delivery_date=datetime.fromisoformat(delivery_data['delivery_date']),
                status=delivery_data['status']
            )
            
            for item_data in delivery_data['items']:
                item = DeliveryItem(
                    product_name=item_data['product_name'],
                    quantity=item_data['quantity'],
                    batch_number=item_data['batch_number']
                )
                delivery.items.append(item)
            
            db.session.add(delivery)
        
        db.session.commit()
        flash('تم استيراد النسخة الاحتياطية بنجاح', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'حدث خطأ أثناء استيراد النسخة الاحتياطية: {str(e)}', 'danger')
    
    return redirect(url_for('view_deliveries'))

with app.app_context():
    # Import models here to avoid circular imports
    import models
    # Create tables if they don't exist
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)